<!DOCTYPE html>
<html>
<head>
<title>Ejercicio1</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link rel="stylesheet" href="css/estilos.css">
</head>
<body >
    <form>
    <div class="formulario">
        <div class="element-container">
           
            <select id="select1" name="select1" class="form-control">
            <option value="opcion1">Seleccione</option>
                <option value="opcion1">Celsius</option>
                <option value="opcion2">Fahrenheit</option>
                <option value="opcion3">Kelvin</option>
            </select>
        </div>

        <div class="element-container">
           
            <select id="select2" name="select2" class="form-control">
            <option value="opcion1">Seleccione</option>
                <option value="opcion4">Celsius</option>
                <option value="opcion5">Fahrenheit</option>
                <option value="opcion6">Kelvin</option>
            </select>
        </div>
<br>
        <div class="element-container">
            <input class="form-control" type="text" id="input1" name="input1">
        </div>
        <div class="element-container">
            <input class="form-control" type="text" id="input2" name="input2">
        </div>
        <div class="control-container">
            <button class="form-control btn btn-primary" type="submit">Calcular</button>
        </div>
    </div>
    </form>
</body>
</html>
