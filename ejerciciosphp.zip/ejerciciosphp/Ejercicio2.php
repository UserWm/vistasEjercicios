<!DOCTYPE html>
<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
   <form action="">
<div class="formulario">
        <div class="control-container">
            <label for="input1" style="color:white">Digité su número:</label>
            <input type="text" id="input1" name="input1" class="form-control">
        </div>

        <div class="control-container">
        <select id="select2" name="select2" class="form-control">
                <option value="opcion4">Precio de compra</option>
                <option value="opcion4">$0.25</option>
                <option value="opcion5">$0.50</option>
                <option value="opcion6">$0.75</option>
                <option value="opcion6">$1.00</option>
            </select>
        </div>
<br>
        <button type="submit" class="form-control btn btn-primary">Jugar</button>
    </div>
    </form>
</body>
</html>
