<!DOCTYPE html>
<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
   <form action="">
<div class="formulario">
        <div class="control-container">
            <label for="input1" style="color:white">KM que recorrera el auto:</label>
            <input type="text" id="input1" name="input1" class="form-control">
        </div>

        <div class="control-container">
        <select id="select2" name="select2" class="form-control">
                <option value="opcion4">Tipo de Sedan</option>
                <option value="opcion4">motor 1.6CC</option>
                <option value="opcion5">motor 1.8CC</option>
                <option value="opcion6">motor 2.0CC</option>
              
            </select>
        </div>
<br>
        <button type="submit" class="form-control btn btn-primary">Calcular consumo</button>
    </div>
    </form>
</body>
</html>
